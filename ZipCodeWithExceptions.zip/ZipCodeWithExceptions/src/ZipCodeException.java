public class ZipCodeException extends Exception {

}
